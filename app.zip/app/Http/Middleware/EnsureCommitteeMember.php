<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnsureCommitteeMember
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        if (!Auth::user()->is_committee_member) {
            if ($request->expectsJson()) {
                return response()->json(['error' => 'Unauthorized. Committee member access required.'], 403);
            }
            
            return redirect()->back()->withErrors([
                'error' => 'Unauthorized. Only committee members can perform this action.'
            ]);
        }

        return $next($request);
    }
}