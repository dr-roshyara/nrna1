<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\VoterSlug;
use App\Services\VotingSecurityService;
use Illuminate\Support\Facades\Log;

/**
 * Middleware to prevent multiple voting by enforcing one active slug per user
 *
 * This middleware runs on every slug-based voting route to ensure
 * no user can have multiple active voting sessions simultaneously
 */
class PreventMultipleVoting
{
    protected VotingSecurityService $securityService;

    public function __construct(VotingSecurityService $securityService)
    {
        $this->securityService = $securityService;
    }

    public function handle(Request $request, Closure $next)
    {
        // Get the voter slug from the route
        $vslug = $request->route('vslug');

        if (!$vslug instanceof VoterSlug) {
            abort(403, 'Invalid voting link');
        }

        $user = $vslug->user;

        // 1. SECURITY CHECK: Enforce one active slug per user
        $enforcement = $this->securityService->enforceOneActiveSlugPerUser($user);

        if ($enforcement['enforcement_needed']) {
            Log::warning('Multiple voting attempt detected and blocked', [
                'user_id' => $user->id,
                'current_slug' => $vslug->slug,
                'deactivated_slugs' => $enforcement['deactivated_slugs'],
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            // Check if the current slug was deactivated
            if (in_array($vslug->slug, $enforcement['deactivated_slugs'])) {
                abort(403, 'This voting link has been deactivated due to security policy. Only one active voting session is allowed per voter.');
            }
        }

        // 2. FINAL VALIDATION: Ensure current slug is still valid after enforcement
        $vslug->refresh(); // Refresh from database in case it was modified

        if (!$vslug->is_active || $vslug->isExpired()) {
            abort(403, 'Voting link is no longer valid. Please request a new voting link.');
        }

        // 3. CHECK FOR COMPLETED VOTING
        if ($user->has_voted) {
            Log::info('User attempted to vote again after completing voting', [
                'user_id' => $user->id,
                'slug' => $vslug->slug,
                'ip_address' => $request->ip(),
            ]);

            abort(403, 'You have already completed voting. Multiple voting is not allowed.');
        }

        // 4. RATE LIMITING: Check for suspicious activity
        $recentRequests = \Cache::get("voting_requests_{$user->id}", 0);
        if ($recentRequests > 100) { // Temporarily increased limit for testing
            Log::warning('Suspicious voting activity - rate limit exceeded', [
                'user_id' => $user->id,
                'requests_per_minute' => $recentRequests,
                'ip_address' => $request->ip(),
            ]);

            abort(429, 'Too many voting requests. Please wait before trying again.');
        }

        \Cache::put("voting_requests_{$user->id}", $recentRequests + 1, 60); // 1 minute cache

        // 5. LOG LEGITIMATE ACCESS
        Log::info('Legitimate voting access granted', [
            'user_id' => $user->id,
            'slug' => $vslug->slug,
            'step' => $vslug->current_step,
            'route' => $request->route()->getName(),
            'ip_address' => $request->ip(),
        ]);

        // All security checks passed - proceed with request
        return $next($request);
    }
}